# INNOXAI - AI Full-Stack Developer Agent

Transform ideas into code with our AI-powered development platform.

## 🚀 Features

- **Real AI Integration** - Powered by Grok AI and OpenAI
- **Live Code Generation** - Watch code generate in real-time
- **Interactive Preview** - See components render instantly
- **Code Editor** - Edit generated code with syntax highlighting
- **Export Options** - Download as ZIP or push to GitHub
- **User Authentication** - Save and manage your components
- **Responsive Design** - Works on desktop, tablet, and mobile

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **UI**: Tailwind CSS, Shadcn/UI, Radix UI
- **Database**: Neon PostgreSQL
- **AI**: Grok AI, OpenAI
- **Authentication**: NextAuth.js
- **Deployment**: Vercel

## 🎯 Quick Start

1. **Clone the repository**
   \`\`\`bash
   git clone https://github.com/your-username/innoxai.git
   cd innoxai
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**
   \`\`\`bash
   cp .env.example .env.local
   \`\`\`

4. **Run the development server**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 🎮 How to Use

1. **Start Generating**: Click the "🧪 Test Analytics Dashboard" button or type any component request
2. **View Code**: Switch to the "Code" tab to see generated TypeScript/React code
3. **Live Preview**: Click "Preview" tab to see your component rendered in real-time
4. **Edit & Export**: Modify code and export as ZIP or push to GitHub

## 📱 Component Examples

Try asking for:
- "Create a dashboard with charts"
- "Build a contact form"
- "Make a todo list app"
- "Design a pricing page"
- "Create a data table"

## 🔧 Configuration

The platform supports various AI providers and can be configured through the UI:
- Grok AI (xAI)
- OpenAI GPT-4
- Custom API endpoints

## 🚀 Deployment

Deploy to Vercel with one click:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/innoxai)

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## 📞 Support

- 📧 Email: support@innoxai.com
- 💬 Discord: [Join our community](https://discord.gg/innoxai)
- 📖 Docs: [Documentation](https://docs.innoxai.com)
