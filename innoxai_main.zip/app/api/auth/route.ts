import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import jwt from "jsonwebtoken"
import bcrypt from "bcryptjs"

const sql = neon(process.env.DATABASE_URL!)
const JWT_SECRET = process.env.JWT_SECRET || "innoxai-secret"

export async function POST(req: NextRequest) {
  try {
    const { action, email, password, name } = await req.json()

    // Initialize users table
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `

    await sql`
      CREATE TABLE IF NOT EXISTS user_components (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        component_name VARCHAR(255) NOT NULL,
        component_code TEXT NOT NULL,
        prompt TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `

    if (action === "register") {
      const hashedPassword = await bcrypt.hash(password, 10)

      const [user] = await sql`
        INSERT INTO users (email, name, password_hash)
        VALUES (${email}, ${name}, ${hashedPassword})
        RETURNING id, email, name
      `

      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET)

      return NextResponse.json({
        success: true,
        user: { id: user.id, email: user.email, name: user.name },
        token,
      })
    }

    if (action === "login") {
      const [user] = await sql`
        SELECT id, email, name, password_hash
        FROM users
        WHERE email = ${email}
      `

      if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
      }

      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET)

      return NextResponse.json({
        success: true,
        user: { id: user.id, email: user.email, name: user.name },
        token,
      })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("Auth error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
