import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { message, projectType = "auto" } = await req.json()

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    // Simple analysis without external dependencies
    const analysis = analyzeRequest(message)

    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Send analysis
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "analysis",
                content: `🔍 **Analysis**: "${message}"\n\n**Type**: ${analysis.type}\n**Stack**: ${analysis.stack}\n\n🚀 **Generating solution...**\n\n`,
              })}\n\n`,
            ),
          )

          // Simulate streaming response
          const response = generateResponse(message, analysis)
          const chunks = response.split(" ")

          for (const chunk of chunks) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "text", content: chunk + " " })}\n\n`))
            await new Promise((resolve) => setTimeout(resolve, 50))
          }

          // Generate codebase
          const codebase = generateCodebase(analysis, message)

          // Stream files
          for (const [filename, content] of Object.entries(codebase.files)) {
            controller.enqueue(
              encoder.encode(
                `data: ${JSON.stringify({
                  type: "file",
                  filename,
                  content,
                  language: getLanguageFromFilename(filename),
                })}\n\n`,
              ),
            )
            await new Promise((resolve) => setTimeout(resolve, 100))
          }

          // Send completion
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "complete",
                content: `✅ **Solution Generated!**\n\n📁 **Files**: ${Object.keys(codebase.files).length}\n🚀 **Ready for use**`,
              })}\n\n`,
            ),
          )

          controller.close()
        } catch (error) {
          console.error("Streaming error:", error)
          controller.error(error)
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("Chat stream error:", error)
    return NextResponse.json({ error: "Failed to generate solution" }, { status: 500 })
  }
}

function analyzeRequest(message: string) {
  const lowerMessage = message.toLowerCase()

  let type = "component"
  const stack = ["react", "typescript", "tailwind"]

  if (lowerMessage.includes("dashboard") || lowerMessage.includes("analytics")) {
    type = "dashboard"
    stack.push("charts")
  } else if (lowerMessage.includes("form")) {
    type = "form"
    stack.push("validation")
  } else if (lowerMessage.includes("table") || lowerMessage.includes("data")) {
    type = "table"
    stack.push("sorting")
  }

  return {
    type,
    stack: stack.join(", "),
    technologies: stack,
  }
}

function generateResponse(message: string, analysis: any): string {
  return `I'll create a ${analysis.type} component for you. This will include modern React with TypeScript, Tailwind CSS styling, and responsive design. The component will be production-ready with proper error handling and accessibility features.`
}

function generateCodebase(analysis: any, message: string) {
  const files: Record<string, string> = {}

  // Generate main component
  files["components/GeneratedComponent.tsx"] = generateComponent(message, analysis)
  files["package.json"] = generatePackageJson()
  files["README.md"] = generateReadme(message)

  return { files }
}

function generateComponent(message: string, analysis: any): string {
  return `"use client"

import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function GeneratedComponent() {
  const [count, setCount] = useState(0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Generated Component</CardTitle>
            <CardDescription>
              Created for: ${message}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <Badge variant="secondary">Type: ${analysis.type}</Badge>
              <Badge variant="outline">Stack: ${analysis.stack}</Badge>
            </div>
            
            <div className="text-center py-8">
              <h2 className="text-2xl font-bold mb-4">Interactive Counter</h2>
              <p className="text-4xl font-bold text-blue-600 mb-4">{count}</p>
              <div className="flex gap-2 justify-center">
                <Button onClick={() => setCount(count - 1)}>-</Button>
                <Button onClick={() => setCount(0)} variant="outline">Reset</Button>
                <Button onClick={() => setCount(count + 1)}>+</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}`
}

function generatePackageJson(): string {
  return JSON.stringify(
    {
      name: "generated-component",
      version: "1.0.0",
      dependencies: {
        react: "^18.2.0",
        "react-dom": "^18.2.0",
        next: "^14.0.0",
        typescript: "^5.0.0",
        tailwindcss: "^3.3.0",
      },
    },
    null,
    2,
  )
}

function generateReadme(message: string): string {
  return `# Generated Component

Created for: **${message}**

## Features
- React with TypeScript
- Tailwind CSS styling
- Responsive design
- Interactive functionality

## Usage
\`\`\`bash
npm install
npm run dev
\`\`\`
`
}

function getLanguageFromFilename(filename: string): string {
  const ext = filename.split(".").pop()
  const langMap: Record<string, string> = {
    ts: "typescript",
    tsx: "typescript",
    js: "javascript",
    jsx: "javascript",
    json: "json",
    md: "markdown",
  }
  return langMap[ext || ""] || "text"
}
