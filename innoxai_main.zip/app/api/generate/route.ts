import { streamText } from "ai"
import { createXai } from "@ai-sdk/xai"
import { openai } from "@ai-sdk/openai"
import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

// Initialize AI providers
const xai = createXai({
  apiKey: process.env.XAI_API_KEY!,
})

const sql = neon(process.env.DATABASE_URL!)

const SYSTEM_PROMPT = `You are INNOXAI, an elite AI full-stack developer agent. Generate production-ready React TypeScript components based on user prompts.

RULES:
1. Always return valid TypeScript React code
2. Use shadcn/ui components: Button, Card, Input, Badge, etc.
3. Include proper imports from '@/components/ui/*'
4. Make components interactive and responsive
5. Add proper TypeScript types
6. Include error handling where appropriate
7. Use Tailwind CSS for styling
8. Make components production-ready

COMPONENT TYPES TO SUPPORT:
- Forms (contact, login, signup, survey)
- Dashboards (analytics, admin, metrics)
- Data tables (sortable, filterable, paginated)
- E-commerce (product cards, checkout, cart)
- Landing pages (hero, features, pricing)
- Navigation (sidebars, headers, menus)
- Content (blogs, portfolios, galleries)

Always include proper state management, event handlers, and realistic data.`

export async function POST(req: NextRequest) {
  try {
    const { prompt, useGrok = true } = await req.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Log the generation request to database
    await sql`
      INSERT INTO ai_generations (prompt, provider, created_at)
      VALUES (${prompt}, ${useGrok ? "grok" : "openai"}, NOW())
    `

    // Choose AI provider
    const model = useGrok && process.env.XAI_API_KEY ? xai("grok-beta") : openai("gpt-4o")

    const result = await streamText({
      model,
      system: SYSTEM_PROMPT,
      prompt: `Generate a React TypeScript component for: ${prompt}

Requirements:
- Use shadcn/ui components
- Include proper TypeScript types
- Make it interactive and responsive
- Add realistic data and state management
- Include proper error handling
- Use Tailwind CSS for styling

Return ONLY the component code, no explanations.`,
      temperature: 0.7,
      maxTokens: 2000,
    })

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Generation error:", error)
    return NextResponse.json({ error: "Failed to generate component" }, { status: 500 })
  }
}
