"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Package, Download, CheckCircle, AlertCircle, Code, Sparkles, Zap } from "lucide-react"
import { DynamicPackageManager } from "@/lib/package-manager"
import { CodeFormatter } from "@/lib/code-formatter"

interface PackageInstallerProps {
  code: string
  onPackagesInstalled: (packages: any[]) => void
  onCodeFormatted: (formattedCode: string) => void
}

export function PackageInstaller({ code, onPackagesInstalled, onCodeFormatted }: PackageInstallerProps) {
  const [detectedPackages, setDetectedPackages] = useState<any[]>([])
  const [installingPackages, setInstallingPackages] = useState<string[]>([])
  const [installedPackages, setInstalledPackages] = useState<string[]>([])
  const [installProgress, setInstallProgress] = useState(0)
  const [lintingResults, setLintingResults] = useState<any>(null)
  const [isFormatting, setIsFormatting] = useState(false)

  useEffect(() => {
    if (code) {
      // Detect packages from code
      const detection = DynamicPackageManager.detectPackagesFromCode(code)
      setDetectedPackages(detection.packages)

      // Lint and format code
      const lintResults = CodeFormatter.lintCode(code)
      setLintingResults(lintResults)
    }
  }, [code])

  const installPackages = async () => {
    if (detectedPackages.length === 0) return

    setInstallingPackages(detectedPackages.map((pkg) => pkg.name))
    setInstallProgress(0)

    // Simulate package installation
    for (let i = 0; i < detectedPackages.length; i++) {
      const pkg = detectedPackages[i]

      // Simulate installation time
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setInstalledPackages((prev) => [...prev, pkg.name])
      setInstallProgress(((i + 1) / detectedPackages.length) * 100)
    }

    setInstallingPackages([])
    onPackagesInstalled(detectedPackages)
  }

  const formatCode = async () => {
    setIsFormatting(true)

    // Simulate formatting time
    await new Promise((resolve) => setTimeout(resolve, 500))

    const formatted = CodeFormatter.formatCode(code)
    onCodeFormatted(formatted)
    setIsFormatting(false)
  }

  const getPackageIcon = (packageName: string) => {
    const iconMap: Record<string, any> = {
      "framer-motion": Sparkles,
      recharts: Package,
      ethers: Zap,
      wagmi: Zap,
      "react-hook-form": Code,
      default: Package,
    }

    const Icon = iconMap[packageName] || iconMap.default
    return <Icon className="h-4 w-4" />
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Smart Package Manager
        </CardTitle>
        <CardDescription>
          Automatically detects and installs required packages, formats code with Prettier and ESLint
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="packages" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="packages">Packages ({detectedPackages.length})</TabsTrigger>
            <TabsTrigger value="formatting">Code Quality</TabsTrigger>
            <TabsTrigger value="config">Configuration</TabsTrigger>
          </TabsList>

          <TabsContent value="packages" className="space-y-4">
            {detectedPackages.length > 0 ? (
              <>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600">Detected {detectedPackages.length} required packages</p>
                  <Button onClick={installPackages} disabled={installingPackages.length > 0} size="sm">
                    {installingPackages.length > 0 ? (
                      <>
                        <Download className="h-4 w-4 mr-2 animate-spin" />
                        Installing...
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4 mr-2" />
                        Install All
                      </>
                    )}
                  </Button>
                </div>

                {installingPackages.length > 0 && (
                  <div className="space-y-2">
                    <Progress value={installProgress} className="w-full" />
                    <p className="text-xs text-gray-500">Installing packages... {Math.round(installProgress)}%</p>
                  </div>
                )}

                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {detectedPackages.map((pkg, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getPackageIcon(pkg.name)}
                          <div>
                            <p className="font-medium text-sm">{pkg.name}</p>
                            <p className="text-xs text-gray-500">{pkg.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {pkg.version}
                          </Badge>
                          {installedPackages.includes(pkg.name) ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : installingPackages.includes(pkg.name) ? (
                            <Download className="h-4 w-4 text-blue-500 animate-spin" />
                          ) : (
                            <Package className="h-4 w-4 text-gray-400" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </>
            ) : (
              <div className="text-center py-8">
                <Package className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">No additional packages required</p>
                <p className="text-xs text-gray-400 mt-1">Your code uses only built-in dependencies</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="formatting" className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">Code Quality Analysis</p>
              <Button onClick={formatCode} disabled={isFormatting} size="sm">
                {isFormatting ? (
                  <>
                    <Code className="h-4 w-4 mr-2 animate-spin" />
                    Formatting...
                  </>
                ) : (
                  <>
                    <Code className="h-4 w-4 mr-2" />
                    Format Code
                  </>
                )}
              </Button>
            </div>

            {lintingResults && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-red-500" />
                        <span className="font-medium">Errors</span>
                        <Badge variant="destructive">{lintingResults.errors.length}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-yellow-500" />
                        <span className="font-medium">Warnings</span>
                        <Badge variant="secondary">{lintingResults.warnings.length}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {[...lintingResults.errors, ...lintingResults.warnings].map((issue, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 border rounded text-sm">
                        <AlertCircle
                          className={`h-4 w-4 mt-0.5 ${issue.severity === "error" ? "text-red-500" : "text-yellow-500"}`}
                        />
                        <div>
                          <p className="font-medium">
                            Line {issue.line}: {issue.message}
                          </p>
                          <p className="text-xs text-gray-500">{issue.rule}</p>
                          {issue.suggestion && <p className="text-xs text-blue-600 mt-1">{issue.suggestion}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}
          </TabsContent>

          <TabsContent value="config" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Prettier Config</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto">
                    {CodeFormatter.generatePrettierConfig()}
                  </pre>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">ESLint Config</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto max-h-32">
                    {CodeFormatter.generateESLintConfig()}
                  </pre>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
