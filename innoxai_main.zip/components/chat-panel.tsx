"use client"

import type React from "react"
import { useState } from "react"

interface ChatPanelProps {
  onMessageSent: (message: string) => void
  isStreaming?: boolean
  projectType?: string
}

const ChatPanel: React.FC<ChatPanelProps> = ({ onMessageSent, isStreaming, projectType }) => {
  const [message, setMessage] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    // Include project type in the message
    const fullMessage =
      projectType && projectType !== "component" ? `[Project Type: ${projectType}] ${message}` : message

    onMessageSent(fullMessage)
    setMessage("")
  }

  // Get suggestions based on project type
  const getSuggestions = () => {
    switch (projectType) {
      case "dapp":
        return [
          "Create a wallet connection component with Wagmi",
          "Build a token swap interface",
          "Create a NFT gallery component",
          "Build a blockchain explorer interface",
        ]
      case "fullstack-app":
        return [
          "Create a user dashboard with API routes",
          "Build a blog with comments and authentication",
          "Create a file upload system with Blob storage",
          "Build a real-time chat application",
        ]
      default:
        return [
          "Create a responsive navigation bar",
          "Build a pricing table component",
          "Create a dark mode toggle",
          "Build a form with validation",
        ]
    }
  }

  const suggestions = getSuggestions()

  return (
    <div className="chat-panel">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
          disabled={isStreaming}
        />
        <button type="submit" disabled={isStreaming}>
          {isStreaming ? "Sending..." : "Send"}
        </button>
      </form>
      <div className="suggestions">
        {suggestions.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => {
              setMessage(suggestion)
            }}
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  )
}

export default ChatPanel
