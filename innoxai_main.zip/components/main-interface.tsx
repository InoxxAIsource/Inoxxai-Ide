"use client"

import type React from "react"
import { useState } from "react"
import ChatPanel from "./chat-panel"
import type Message from "./message"
import { BlockchainProvider } from "./blockchain-provider"
import { WalletConnect } from "./wallet-connect"
import { ProjectTypeSelector } from "./project-type-selector"
import { PackageInstaller } from "./package-installer"
import { Package } from "lucide-react"
import { Button } from "@/components/ui/button"

const MainInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([])
  const [isStreaming, setIsStreaming] = useState<boolean>(false)
  const [projectType, setProjectType] = useState<string>("component")
  const [showPackageInstaller, setShowPackageInstaller] = useState(false)
  const [installedPackages, setInstalledPackages] = useState<any[]>([])
  const [generatedCode, setGeneratedCode] = useState<string>("")

  const handleMessageSent = (newMessage: Message) => {
    setMessages([...messages, newMessage])
  }

  const handlePackagesInstalled = (packages: any[]) => {
    setInstalledPackages(packages)
    console.log("Packages installed:", packages)
  }

  const handleCodeFormatted = (formattedCode: string) => {
    setGeneratedCode(formattedCode)
    console.log("Code formatted")
  }

  return (
    <BlockchainProvider>
      <div className="flex flex-col h-screen">
        <WalletConnect />
        <ProjectTypeSelector onSelect={setProjectType} selectedType={projectType} />
        <div className="flex-grow overflow-y-auto p-4">
          {messages.map((message, index) => (
            <div key={index} className={`mb-2 ${message.isUser ? "text-right" : "text-left"}`}>
              <span
                className={`inline-block p-2 rounded ${message.isUser ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-800"}`}
              >
                {message.text}
              </span>
            </div>
          ))}
        </div>
        <div className="flex justify-end p-2">
          <Button variant="ghost" size="sm" onClick={() => setShowPackageInstaller(!showPackageInstaller)}>
            <Package className="h-4 w-4" />
            Packages
          </Button>
        </div>
        {showPackageInstaller && generatedCode && (
          <div className="border-b">
            <PackageInstaller
              code={generatedCode}
              onPackagesInstalled={handlePackagesInstalled}
              onCodeFormatted={handleCodeFormatted}
            />
          </div>
        )}
        <ChatPanel onMessageSent={handleMessageSent} isStreaming={isStreaming} projectType={projectType} />
      </div>
    </BlockchainProvider>
  )
}

export default MainInterface
