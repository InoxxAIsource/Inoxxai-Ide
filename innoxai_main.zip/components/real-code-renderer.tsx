"use client"

import React from "react"
import { useMDXComponent } from "mdx-js/react"
import * as components from "@/components/ui"
import * as shadcnComponents from "@/components/ui"
import * as blockchainComponents from "@/components/blockchain"
import * as LucideIcons from "lucide-react"
import { ethers } from "ethers"
import { ERC20_ABI, getProvider, getContract } from "@/lib/blockchain-utils"

interface CodeRendererProps {
  code: string
  scope: { [key: string]: any }
}

const CodeRenderer: React.FC<CodeRendererProps> = ({ code, scope }) => {
  const globalEthers = {
    ethers,
    getProvider,
    getContract,
    ERC20_ABI,
  }

  const evalCode = (code: string) => {
    try {
      // Create a function with the code and the scope as arguments
      const AsyncFunction = Object.getPrototypeOf(async () => {}).constructor
      const func = new AsyncFunction(...Object.keys(scope), "globalEthers", code)

      // Call the function with the scope values as arguments
      return func(...Object.values(scope), globalEthers)
    } catch (error: any) {
      console.error("Error evaluating code:", error)
      return Promise.resolve(`Error: ${error.message}`)
    }
  }

  const renderCode = async (code: string) => {
    try {
      const processedCode = await evalCode(code)
      return processedCode
    } catch (error: any) {
      console.error("Error rendering code:", error)
      return `Error: ${error.message}`
    }
  }

  const CodeBlock = React.useMemo(() => {
    const asyncMDX = async () => {
      try {
        const processedCode = await renderCode(code)

        // Wrap in module format
        return `
  import React, { useState, useEffect, useRef } from 'react';
  const shadcnComponents = ${JSON.stringify(Object.keys(shadcnComponents))}.reduce((acc, key) => {
    acc[key] = shadcnComponents[key];
    return acc;
  }, {});
  const blockchainComponents = ${JSON.stringify(Object.keys(blockchainComponents))}.reduce((acc, key) => {
    acc[key] = blockchainComponents[key];
    return acc;
  }, {});
  const LucideIcons = ${JSON.stringify(Object.keys(LucideIcons))}.reduce((acc, key) => {
    acc[key] = LucideIcons[key];
    return acc;
  }, {});
  const ethers = globalEthers.ethers;
  const getProvider = globalEthers.getProvider;
  const getContract = globalEthers.getContract;
  const ERC20_ABI = globalEthers.ERC20_ABI;
  ${processedCode}
`
      } catch (error: any) {
        console.error("Error creating MDX content:", error)
        return `export default () => <div>Error: ${error.message}</div>`
      }
    }

    const generateComponent = async () => {
      const mdxContent = await asyncMDX()
      const AsyncFunction = Object.getPrototypeOf(async () => {}).constructor
      const func = new AsyncFunction(
        "React",
        "components",
        "shadcnComponents",
        "blockchainComponents",
        "LucideIcons",
        "globalEthers",
        mdxContent,
      )
      const result = await func(React, components, shadcnComponents, blockchainComponents, LucideIcons, globalEthers)
      return result
    }

    return generateComponent()
  }, [code])

  const MdxComponent = useMDXComponent(CodeBlock)

  return (
    <MdxComponent
      {...components}
      {...shadcnComponents}
      {...blockchainComponents}
      {...LucideIcons}
      ethers={globalEthers.ethers}
      getProvider={globalEthers.getProvider}
      getContract={globalEthers.getContract}
      ERC20_ABI={globalEthers.ERC20_ABI}
    />
  )
}

export default CodeRenderer
