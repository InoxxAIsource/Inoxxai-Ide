"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Download, FileCode, Eye } from "lucide-react"

interface CodeEditorProps {
  code: string
  onChange: (code: string) => void
  isStreaming?: boolean
}

export function CodeEditor({ code, onChange, isStreaming }: CodeEditorProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    if (code) {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleDownload = () => {
    if (code) {
      const blob = new Blob([code], { type: "text/typescript" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "generated-component.tsx"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <FileCode className="h-4 w-4" />
          <span className="font-medium">Code Editor</span>
          <Badge variant="secondary">TypeScript React</Badge>
          {isStreaming && (
            <Badge variant="outline" className="gap-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              Generating...
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={handleCopy} disabled={!code}>
            <Copy className="h-4 w-4" />
            {copied ? "Copied!" : "Copy"}
          </Button>
          <Button variant="ghost" size="sm" onClick={handleDownload} disabled={!code}>
            <Download className="h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      {/* Code Content */}
      <div className="flex-1 overflow-hidden">
        {!code ? (
          <div className="h-full flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <FileCode className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Code Generated Yet</h3>
              <p className="text-gray-600 mb-4">Start a conversation with the AI to generate code</p>
              <div className="flex items-center gap-2 justify-center">
                <Eye className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-500">Code will appear here and preview below</span>
              </div>
            </div>
          </div>
        ) : (
          <ScrollArea className="h-full">
            <pre className="p-4 text-sm font-mono bg-gray-900 text-gray-100 min-h-full overflow-auto">
              <code className="language-typescript">{code}</code>
            </pre>
          </ScrollArea>
        )}
      </div>

      {/* Footer */}
      <div className="p-2 border-t bg-gray-50 text-xs text-gray-600 flex items-center justify-between">
        <span>Lines: {code ? code.split("\n").length : 0}</span>
        <span>Characters: {code ? code.length : 0}</span>
      </div>
    </div>
  )
}
