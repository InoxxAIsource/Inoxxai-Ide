"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Download, Trash2, Eye, Copy, Calendar, Code, User, Sparkles } from "lucide-react"

interface SavedComponent {
  id: string
  name: string
  code: string
  prompt: string
  userId?: string
  createdAt: string
  blobUrl: string
}

interface ComponentLibraryProps {
  user?: any
  onLoadComponent?: (component: SavedComponent) => void
}

export function ComponentLibrary({ user, onLoadComponent }: ComponentLibraryProps) {
  const [components, setComponents] = useState<SavedComponent[]>([])
  const [filteredComponents, setFilteredComponents] = useState<SavedComponent[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const fetchComponents = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/components${user ? `?userId=${user.id}` : ""}`)
      const data = await response.json()

      if (data.success) {
        setComponents(data.components)
        setFilteredComponents(data.components)
      }
    } catch (error) {
      console.error("Failed to fetch components:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchComponents()
  }, [user])

  useEffect(() => {
    const filtered = components.filter(
      (component) =>
        component.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        component.prompt?.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredComponents(filtered)
  }, [searchTerm, components])

  const handleDelete = async (componentId: string) => {
    if (!confirm("Are you sure you want to delete this component?")) return

    try {
      const response = await fetch(`/api/components?id=${componentId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setComponents((prev) => prev.filter((c) => c.id !== componentId))
      }
    } catch (error) {
      console.error("Failed to delete component:", error)
    }
  }

  const handleExport = async (component: SavedComponent) => {
    try {
      const response = await fetch("/api/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          componentName: component.name,
          code: component.code,
          includePackageJson: true,
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Download the ZIP file
        const link = document.createElement("a")
        link.href = data.downloadUrl
        link.download = data.filename
        link.click()
      }
    } catch (error) {
      console.error("Failed to export component:", error)
    }
  }

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Component Library</h2>
          <p className="text-gray-600">Your saved AI-generated components</p>
        </div>
        <Badge variant="secondary">
          {filteredComponents.length} component{filteredComponents.length !== 1 ? "s" : ""}
        </Badge>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search components..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Components Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-4"></div>
                <div className="h-3 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
                <div className="flex gap-2">
                  <div className="h-8 w-16 bg-gray-200 rounded"></div>
                  <div className="h-8 w-16 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredComponents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredComponents.map((component) => (
            <Card key={component.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{component.name}</CardTitle>
                  <Badge variant="outline" className="text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    AI
                  </Badge>
                </div>
                {component.prompt && (
                  <CardDescription className="text-sm line-clamp-2">{component.prompt}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Calendar className="h-3 w-3" />
                  {new Date(component.createdAt).toLocaleDateString()}
                  {component.userId && (
                    <>
                      <User className="h-3 w-3 ml-2" />
                      Private
                    </>
                  )}
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button size="sm" variant="outline" onClick={() => onLoadComponent?.(component)} className="gap-1">
                    <Eye className="h-3 w-3" />
                    Load
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => copyCode(component.code)} className="gap-1">
                    <Copy className="h-3 w-3" />
                    Copy
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport(component)} className="gap-1">
                    <Download className="h-3 w-3" />
                    Export
                  </Button>
                  {user && component.userId === user.id && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(component.id)}
                      className="gap-1 text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-3 w-3" />
                      Delete
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <Code className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Components Found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? "No components match your search." : "Start generating components to build your library!"}
            </p>
            {searchTerm && (
              <Button variant="outline" onClick={() => setSearchTerm("")}>
                Clear Search
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
