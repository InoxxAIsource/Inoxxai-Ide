interface PackageInfo {
  name: string
  version: string
  description: string
  dependencies?: string[]
}

interface PackageDetectionResult {
  packages: PackageInfo[]
  imports: string[]
  suggestions: string[]
}

export class DynamicPackageManager {
  private static packageDatabase: Record<string, PackageInfo> = {
    // UI Libraries
    "framer-motion": { name: "framer-motion", version: "^10.16.4", description: "Animation library" },
    "react-spring": { name: "react-spring", version: "^9.7.3", description: "Spring animations" },
    "lottie-react": { name: "lottie-react", version: "^2.4.0", description: "Lottie animations" },

    // Charts & Data Visualization
    recharts: { name: "recharts", version: "^2.8.0", description: "Chart library" },
    "chart.js": { name: "chart.js", version: "^4.4.0", description: "Chart.js library" },
    "react-chartjs-2": { name: "react-chartjs-2", version: "^5.2.0", description: "React Chart.js wrapper" },
    d3: { name: "d3", version: "^7.8.5", description: "Data visualization" },

    // Forms & Validation
    "react-hook-form": { name: "react-hook-form", version: "^7.48.2", description: "Form library" },
    zod: { name: "zod", version: "^3.22.4", description: "Schema validation" },
    yup: { name: "yup", version: "^1.3.3", description: "Schema validation" },
    formik: { name: "formik", version: "^2.4.5", description: "Form library" },

    // State Management
    zustand: { name: "zustand", version: "^4.4.7", description: "State management" },
    jotai: { name: "jotai", version: "^2.6.0", description: "Atomic state management" },
    redux: { name: "redux", version: "^5.0.0", description: "State management" },
    "@reduxjs/toolkit": { name: "@reduxjs/toolkit", version: "^2.0.1", description: "Redux toolkit" },

    // Data Fetching
    swr: { name: "swr", version: "^2.2.4", description: "Data fetching" },
    "@tanstack/react-query": { name: "@tanstack/react-query", version: "^5.14.2", description: "Data fetching" },
    axios: { name: "axios", version: "^1.6.2", description: "HTTP client" },

    // Blockchain/Web3
    ethers: { name: "ethers", version: "^6.8.1", description: "Ethereum library" },
    wagmi: { name: "wagmi", version: "^1.4.12", description: "React hooks for Ethereum" },
    viem: { name: "viem", version: "^1.21.4", description: "TypeScript Ethereum library" },
    "@rainbow-me/rainbowkit": { name: "@rainbow-me/rainbowkit", version: "^1.3.3", description: "Wallet connection" },
    web3: { name: "web3", version: "^4.3.0", description: "Web3 library" },

    // Utilities
    "date-fns": { name: "date-fns", version: "^2.30.0", description: "Date utilities" },
    lodash: { name: "lodash", version: "^4.17.21", description: "Utility library" },
    uuid: { name: "uuid", version: "^9.0.1", description: "UUID generator" },
    nanoid: { name: "nanoid", version: "^5.0.4", description: "ID generator" },

    // File Handling
    "react-dropzone": { name: "react-dropzone", version: "^14.2.3", description: "File upload" },
    "file-saver": { name: "file-saver", version: "^2.0.5", description: "File saving" },

    // Markdown & Rich Text
    "react-markdown": { name: "react-markdown", version: "^9.0.1", description: "Markdown renderer" },
    "@uiw/react-md-editor": { name: "@uiw/react-md-editor", version: "^4.0.4", description: "Markdown editor" },

    // Testing
    "@testing-library/react": { name: "@testing-library/react", version: "^14.1.2", description: "React testing" },
    jest: { name: "jest", version: "^29.7.0", description: "Testing framework" },

    // Development Tools
    prettier: { name: "prettier", version: "^3.1.1", description: "Code formatter" },
    eslint: { name: "eslint", version: "^8.56.0", description: "Code linter" },
    "@typescript-eslint/eslint-plugin": {
      name: "@typescript-eslint/eslint-plugin",
      version: "^6.17.0",
      description: "TypeScript ESLint",
    },
  }

  private static importPatterns: Record<string, string[]> = {
    "framer-motion": ["motion", "AnimatePresence", "useAnimation"],
    "react-spring": ["useSpring", "animated", "useTransition"],
    recharts: ["LineChart", "BarChart", "PieChart", "XAxis", "YAxis", "CartesianGrid", "Tooltip", "Legend"],
    "react-hook-form": ["useForm", "Controller", "FormProvider"],
    zod: ["z", "ZodSchema"],
    ethers: ["ethers", "Contract", "providers"],
    wagmi: ["useAccount", "useConnect", "useDisconnect", "useContractRead", "useContractWrite"],
    "date-fns": ["format", "parseISO", "addDays", "subDays"],
    lodash: ["debounce", "throttle", "cloneDeep", "merge"],
    swr: ["useSWR", "mutate"],
    "@tanstack/react-query": ["useQuery", "useMutation", "useQueryClient"],
  }

  static detectPackagesFromCode(code: string): PackageDetectionResult {
    const packages: PackageInfo[] = []
    const imports: string[] = []
    const suggestions: string[] = []

    // Extract existing imports
    const importRegex = /import\s+(?:{[^}]+}|\w+|\*\s+as\s+\w+)\s+from\s+['"]([^'"]+)['"]/g
    let match
    while ((match = importRegex.exec(code)) !== null) {
      imports.push(match[1])
    }

    // Detect usage patterns that suggest packages
    const detectionPatterns = [
      // Animation patterns
      { pattern: /motion\.|AnimatePresence|useAnimation/, package: "framer-motion" },
      { pattern: /useSpring|animated\.|useTransition/, package: "react-spring" },

      // Chart patterns
      { pattern: /LineChart|BarChart|PieChart|XAxis|YAxis/, package: "recharts" },
      { pattern: /Chart\.js|chartjs/, package: "chart.js" },

      // Form patterns
      { pattern: /useForm|Controller|register/, package: "react-hook-form" },
      { pattern: /z\.|ZodSchema|zodResolver/, package: "zod" },

      // State management
      { pattern: /create$$.*$$|useStore/, package: "zustand" },
      { pattern: /atom\(|useAtom/, package: "jotai" },

      // Data fetching
      { pattern: /useSWR|mutate/, package: "swr" },
      { pattern: /useQuery|useMutation/, package: "@tanstack/react-query" },
      { pattern: /axios\.|get\(|post\(/, package: "axios" },

      // Blockchain
      { pattern: /ethers\.|Contract|providers/, package: "ethers" },
      { pattern: /useAccount|useConnect|useContractRead/, package: "wagmi" },
      { pattern: /createPublicClient|createWalletClient/, package: "viem" },

      // Date handling
      { pattern: /format\(|parseISO|addDays/, package: "date-fns" },

      // Utilities
      { pattern: /debounce\(|throttle\(|cloneDeep/, package: "lodash" },
      { pattern: /uuid$$$$|v4$$$$/, package: "uuid" },

      // File handling
      { pattern: /useDropzone|getRootProps/, package: "react-dropzone" },
      { pattern: /saveAs\(/, package: "file-saver" },

      // Markdown
      { pattern: /ReactMarkdown|markdown/, package: "react-markdown" },
    ]

    // Check for patterns in code
    detectionPatterns.forEach(({ pattern, package: packageName }) => {
      if (pattern.test(code) && !imports.includes(packageName)) {
        const packageInfo = this.packageDatabase[packageName]
        if (packageInfo && !packages.find((p) => p.name === packageName)) {
          packages.push(packageInfo)
          suggestions.push(`Detected usage of ${packageName}`)
        }
      }
    })

    // Check for common component patterns
    if (/dashboard|analytics|chart/i.test(code) && !packages.find((p) => p.name === "recharts")) {
      packages.push(this.packageDatabase["recharts"])
      suggestions.push("Dashboard detected - added Recharts for data visualization")
    }

    if (/form|input|validation/i.test(code) && !packages.find((p) => p.name === "react-hook-form")) {
      packages.push(this.packageDatabase["react-hook-form"])
      packages.push(this.packageDatabase["zod"])
      suggestions.push("Form detected - added React Hook Form and Zod validation")
    }

    if (/wallet|connect|ethereum|blockchain/i.test(code) && !packages.find((p) => p.name === "wagmi")) {
      packages.push(this.packageDatabase["wagmi"])
      packages.push(this.packageDatabase["ethers"])
      suggestions.push("Blockchain functionality detected - added Wagmi and Ethers")
    }

    return { packages, imports, suggestions }
  }

  static generatePackageJson(detectedPackages: PackageInfo[], basePackageJson: any): any {
    const newPackageJson = { ...basePackageJson }

    detectedPackages.forEach((pkg) => {
      if (!newPackageJson.dependencies[pkg.name]) {
        newPackageJson.dependencies[pkg.name] = pkg.version
      }
    })

    // Always include development dependencies for code quality
    const devDeps = {
      prettier: "^3.1.1",
      eslint: "^8.56.0",
      "@typescript-eslint/eslint-plugin": "^6.17.0",
      "@typescript-eslint/parser": "^6.17.0",
      "eslint-config-prettier": "^9.1.0",
      "eslint-plugin-react": "^7.33.2",
      "eslint-plugin-react-hooks": "^4.6.0",
    }

    newPackageJson.devDependencies = { ...newPackageJson.devDependencies, ...devDeps }

    return newPackageJson
  }

  static generateImportStatements(packages: PackageInfo[]): string[] {
    const imports: string[] = []

    packages.forEach((pkg) => {
      const patterns = this.importPatterns[pkg.name]
      if (patterns) {
        imports.push(`import { ${patterns.join(", ")} } from '${pkg.name}'`)
      }
    })

    return imports
  }
}
