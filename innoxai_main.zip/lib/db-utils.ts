import { PrismaClient } from "@prisma/client"

// PrismaClient is attached to the `global` object in development to prevent
// exhausting your database connection limit.
const globalForPrisma = global as unknown as { prisma: PrismaClient }

export const prisma = globalForPrisma.prisma || new PrismaClient()

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma

// Helper functions for common database operations

export async function createUser(data: {
  email: string
  name?: string
  walletAddress?: string
}) {
  return prisma.user.create({
    data,
  })
}

export async function getUserByEmail(email: string) {
  return prisma.user.findUnique({
    where: { email },
  })
}

export async function getUserByWallet(walletAddress: string) {
  return prisma.user.findFirst({
    where: { walletAddress },
  })
}

export async function updateUser(id: string, data: any) {
  return prisma.user.update({
    where: { id },
    data,
  })
}

// Project related helpers
export async function createProject(data: {
  name: string
  description?: string
  userId: string
  projectType: string
}) {
  return prisma.project.create({
    data,
  })
}

export async function getProjectsByUser(userId: string) {
  return prisma.project.findMany({
    where: { userId },
    orderBy: { updatedAt: "desc" },
  })
}

export async function getProjectById(id: string) {
  return prisma.project.findUnique({
    where: { id },
  })
}

// Component related helpers
export async function saveComponent(data: {
  name: string
  code: string
  projectId: string
  description?: string
}) {
  return prisma.component.create({
    data,
  })
}

export async function getComponentsByProject(projectId: string) {
  return prisma.component.findMany({
    where: { projectId },
    orderBy: { updatedAt: "desc" },
  })
}
